<?php
session_start();
if(isset($_SESSION['orgadmin_session'])){
?>
						<!-- header area -->
<!DOCTYPE html>
<html lang="es-us">
<meta charset="utf-8">
<head>
<title> Student Association management in DUET </title>
<link href="style.css" rel="stylesheet" type="text/css">
<link href="content.css" rel="stylesheet" type="text/css">

</head>
<body>	
	<div class="fix wraper">
			<div class="fix mainheader">
					<div class="fix new_header">
						<div class="fix title">
							<img src="icon/fb.png" alt="" style="width:30px;height:30px;float:left;border-radius:50%;margin-right:10px;"/>
							<img src="icon/youtube.png" alt="" style="width:30px;height:30px;float:left;border-radius:50%;"/>
				
							<center><h2>Student Welfare Association in DUET</h2></center>
							<input type="text" placeholder="search" name="searchbtn" style="float:right;padding:4px;margin-top:-25px;border-radius:4px;"/>
						</div>

					</div>  
					<div class="fix manu">
						<ul>
							<li><a href="index.php">HOME</a></li>
							<li><a href="#">CONTACT</a></li>
							<li><a href ="#">INFO</a></li>
							<li><a href="superadmin_dasboard.php">DASBOARD</a></li>
							
							
							<li><a href="#">ADMIN</a>
									<ul>

										
										<li><a href='superadmin_login.php'>Super admin Login</a></li>
					
										<li><a href="login.php">Association admin Login</a></li>
										
									</ul>
							</li>
							<li><a href ="#">USER</a>
									<ul>
										
										
													<?php
											if(isset($_SESSION['mail'])){
												echo "<li><a href='logout.php'>Logout</a></li>";	
												echo "<li><a href='profile.php'>Profile</a></li>";	
											}
											else{
												echo "<li><a href='register.php'>Register</a></li>";
												echo "<li><a href='login.php'>Login</a></li>";
											}
										?>
									</ul>
							
							</li>
						</ul>
					</div>
			</div>
			
		
				<div class="fix maincontent" style="padding:10px;">
			
						<div class="regfrom">
							<?php
								include("config.php");
								$org=$_SESSION['orgadmin_session'];;
								$edit_id=$_REQUEST["edit_id"];
								$query="select * from alluser where id='$edit_id'";
								$runquery=mysqli_query($connect,$query);
								while($mydata=mysqli_fetch_array($runquery)){
								?>	
								<center>
									<form action="" method="POST">
										<label for="">Frist Name</label><br />
										<input type="text" name="fname" value="<?php echo $mydata['fname'];?>"/><br />
										<label for="">Last Name</label><br />
										<input type="text" name="lname" value="<?php echo $mydata['lname'];?>"/><br />
										<label for="">Student Id</label><br />
										<input type="text" name="sid" value="<?php echo $mydata['sid'];?>"/><br />
										<label for="">Batch no</label><br />
										<input type="text" name="batch" value="<?php echo $mydata['batch'];?>"/><br />
										<label for="">Department</label><br />
										<input type="text" name="dept" value="<?php echo $mydata['dept'];?>"/><br />
										<label for="">Phone number</label><br />
										<input type="text" name="phonenumber" value="<?php echo $mydata['phonenumber'];?>"/><br />
										<label for="">Whatsapp number</label><br />
										<input type="text" name="whatsapp" value="<?php echo $mydata['whatsapp'];?>"/><br />
										<label for="">Blood Group</label><br />
										<input type="text" name="bloodgroup" value="<?php echo $mydata['bloodgroup'];?>"/><br />
										<label for="">Wroks at</label><br />
										<input type="text" name="wroksat" value="<?php echo $mydata['wroksat'];?>"/><br />
										<label for="">Present Address</label><br />
										<input type="text" name="presentaddr" value="<?php echo $mydata['presentaddr'];?>"/><br />
										<label for="">Parmanent Address</label><br />
										<input type="text" name="parmanentaddr" value="<?php echo $mydata['parmanentaddr'];?>"/><br />
										<label for="">Social Link</label><br />
										<input type="text" name="sociallink" value="<?php echo $mydata['sociallink'];?>"/><br />
										<label for="">Biodata</label><br />
										<input type="text" name="biodata" value="<?php echo $mydata['biodata'];?>"/><br />
										<input type="submit" value="Update Profile" id="subbtn"/>
										
										<input type="hidden" name="editprofile" value="<?php echo $mydata['id'];?>"/>
									
									</form>
								</center>	
							<?php
								}
							?>		

						</div>							
								
					

				</div>
				<?php
					if(isset($_REQUEST['editprofile'])){
						$fname=$_REQUEST["fname"];
						$lname=$_REQUEST["lname"];
						$sid=$_REQUEST["sid"];
						$batch=$_REQUEST["batch"];
						$dept=$_REQUEST["dept"];
						$phonenumber=$_REQUEST["phonenumber"];
						$whatsapp=$_REQUEST["whatsapp"];
						$bloodgroup=$_REQUEST["bloodgroup"];
						$wroksat=$_REQUEST["wroksat"];
						$presentaddr=$_REQUEST["presentaddr"];
						$parmanentaddr=$_REQUEST["parmanentaddr"];
						$sociallink=$_REQUEST["sociallink"];
						$biodata=$_REQUEST["biodata"];
						
						$editprofile=$_REQUEST["editprofile"];
						
						$update_table=$_SESSION['superadmin_session_org'];
						$query="update alluser set fname='$fname',lname='$lname',sid='$sid',batch='$batch',dept='$dept',phonenumber='$phonenumber',whatsapp='$whatsapp',bloodgroup='$bloodgroup',wroksat='$wroksat',presentaddr='$presentaddr',parmanentaddr='$parmanentaddr',sociallink='$sociallink',biodata='$biodata' where id='$editprofile'";
						$runquery=mysqli_query($connect,$query);
						if($runquery==true){
							header("location:orgadmin_view.php?view_id='$editprofile'");
						}
						
					}
				
				?>
	
				<!-- saidbar -->
				<?php
					include('footer.php');
					
				?>
				<?php
				}
				else{
					header("location:index.php");
				}
				?>