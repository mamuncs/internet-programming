				<?php
					session_start();
					if(isset($_SESSION['orgadmin_session'])){
				?>
						<!-- header area -->
<!DOCTYPE html>
<html lang="es-us">
<meta charset="utf-8">
<head>
<title> Student Association management in DUET </title>
<link href="style.css" rel="stylesheet" type="text/css">
<link href="content.css" rel="stylesheet" type="text/css">

</head>
<body>	
	<div class="fix wraper">
			<div class="fix mainheader">
					<div class="fix new_header">
						<div class="fix title">
							<a href="https://www.facebook.com/"><img src="icon/fb.png" alt="" style="width:30px;height:30px;float:left;border-radius:50%;margin-right:10px;"/></a>
							<a href="htpps://www.youtube.com/"><img src="icon/youtube.png" alt="" style="width:30px;height:30px;float:left;border-radius:50%;"/></a>
							<center><h2>Student Welfare Association in DUET</h2></center>
							<input type="text" placeholder="search" name="searchbtn" style="float:right;padding:4px;margin-top:-25px;border-radius:4px;"/>
						</div>

					</div>  
					<div class="fix manu">
						<ul>
							<li><a href="index.php">HOME</a></li>
							<li><a href="#">CONTACT</a></li>
							<li><a href ="orgadmin_dasboard.php">DASBOARD</a></li>
							<li><a href="orgadmin_dasboard.php?allmemberbtn=Show+All+Member">AllMEMBER</a></li>
							
							
							<li><a href="#">ADMIN</a>
									<ul>

										
										<li><a href='superadmin_login.php'>Super admin</a></li>
					
										<li><a href="login.php">Association admin</a></li>
										<li><a href="admin_logout.php">Logout</a></li>
										
									</ul>
							</li>
							<li><a href ="#">USER</a>
									<ul>
										
										
													<?php
											if(isset($_SESSION['mail'])){
												echo "<li><a href='logout.php'>Logout</a></li>";	
												echo "<li><a href='profile.php'>Profile</a></li>";	
											}
											else{
												echo "<li><a href='register.php'>Register</a></li>";
												echo "<li><a href='login.php'>Login</a></li>";
											}
										?>
									</ul>
							
							</li>
						</ul>
					</div>
			</div>
			
		
				<div class="fix maincontent" style="padding:10px;">


						
							<div class="allcontent">
								<h2>Add student</h2>
								
								<form action="" method="POST">

										<label for="First Name">First Name</label><br />
										<input type="text" name="fname"/>
										<br />
										<label for="Last Name">Last Name</label><br />
										<input type="text" name="lname"/>
										<br />
										<label for="Email">Email</label><br />
										<input type="text" name="email"/>
										<br />
										<label for="Student Id">Student Id</label><br />
										<input type="text" name="sid"/>
										
										<br />
										<label for="password">Password</label><br />
										<input type="text" name="password"/>
										<br />

										<br />
										<input type="submit" value="Add_User" name="submitbtn" id="subbtn"/>
										
								</form>
								
							</div>
					<div class="leftbar">
						<form action="">
							<input type="text" name="searchId"/>
							<input type="submit" value="search" name="searchbtn"/>
						</form>
					


					</div>
					<div class="leftbar1">
						<form action="">
							<input type="submit" value="Show All Member" name="allmemberbtn"/>
						</form>
					


					</div>
					

				</div>
					<div class="data" style="padding:10px;text-align:center">
						<?php
							include("config.php");
							$orgname=$_SESSION['orgadmin_session'];
							if(isset($_REQUEST['allmemberbtn'])){
								if(!empty($orgname)){
								?>
								<table border="1px solid green" style="width:100%;margin:0 auto">
									<tr>
										<td>First Name</td>
										<td>Last Name</td>
										<td>Student Id</td>
										<td>Association Name</td>
										<td>Profile</td>
										<td>Edit profile</td>
										<td>delete profile</td>

										
									</tr>
								<?php
							
								
								$query="select * from alluser where orgname='$orgname'";
								$runquery=mysqli_query($connect,$query);
								while($mydata=mysqli_fetch_array($runquery)){
									?>
								
									<tr>
										<td><?php echo $mydata['fname'];?></td>
										<td><?php echo $mydata['lname'];?></td>
										<td><?php echo $mydata['sid'];?></td>
										<td><?php echo $mydata['orgname'];?></td>
										<td><a href="orgadmin_view.php?view_id=<?php echo $mydata['id']?>">view</a></td>
										<td><a href="orgadmin_edit.php?edit_id=<?php echo $mydata['id']?>">Edit</a></td>
										<td><a onclick="return confirm('Are you want to delete your Account?');" href="orgadmin_deletedata_core.php?del_id=<?php echo $mydata['id']?>">Delete</a></td>
										
									</tr>
								<?php
								}
								?>
								</table>
								
								<?php
								
								
								}
						}
						else if(isset($_REQUEST['searchbtn'])){
							$searchId=$_REQUEST['searchId'];
								if(!empty($searchId)){
								?>
								<table border="1px solid green" style="width:100%;margin:0 auto">
									<tr>
										<td>First Name</td>
										<td>Last Name</td>
										<td>Student Id</td>
										<td>Association Name</td>
										<td>Profile</td>
										<td>Edit profile</td>
										<td>delete profile</td>

										
									</tr>
								<?php
							
								
								$query="select * from alluser where orgname='$orgname' and sid like '%$searchId%'";
								$runquery=mysqli_query($connect,$query);
								while($mydata=mysqli_fetch_array($runquery)){
									?>
								
									<tr>
										<td><?php echo $mydata['fname'];?></td>
										<td><?php echo $mydata['lname'];?></td>
										<td><?php echo $mydata['sid'];?></td>
										<td><?php echo $mydata['orgname'];?></td>
										<td><a href="orgadmin_view.php?view_id=<?php echo $mydata['id']?>">view</a></td>
										<td><a href="orgadmin_edit.php?edit_id=<?php echo $mydata['id']?>">Edit</a></td>
										<td><a onclick="return confirm('Are you want to delete your Account?');" href="orgadmin_deletedata_core.php?del_id=<?php echo $mydata['id']?>">Delete</a></td>
										
									</tr>
								<?php
								}
								?>
								</table>
								
								<?php
								
								
								}
						}
							
								
						?>
						
					
					
					</div>
					<?php
						if(isset($_REQUEST['submitbtn'])){
									$fname=$_REQUEST['fname'];
									 $lname=$_REQUEST['lname'];
					
									$email=$_REQUEST['email'];
									$sid=$_REQUEST['sid'];
									$password=$_REQUEST['password'];
							if(empty($fname &&$lname&&$email&&$sid&&$password)){
								echo "<center>Fillup all fields</center>";		
	
							}
							else{
																
									$query="insert into alluser(fname,lname,email,orgname,password,conpassword,sid)values('$fname','$lname','$email','$orgname','$password','$password','$sid');";
									$runquery=mysqli_query($connect,$query);
									if($runquery==true){
										echo "<center>A New Account is created.</center>";
									} 
							}

						}

					?>
				<!-- saidbar -->
				<?php
					include('footer.php');
				?>
				<?php
					}
					else{
						header("location:index.php");
					}
				?>	
				