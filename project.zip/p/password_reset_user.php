<?php
	session_start();
	
	
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>your profile</title>
	<link rel="stylesheet" href="style.css" type="text/css"/>
	
</head>
<body>
	<div class="sendmail">
			<center><h3>Student Association Welfare in DUET</h3></center>
			<hr />
		<div class="mail">
			<form action="" method="POST">
				<label for="OTP">Enter Send OTP
				</label><br />
				<input type="text" name="otp"/><br />
				<label for="Password">Enter New Password
				</label><br />
				<input type="text" name="new_password"/>
				<br />
				<input type="submit" value="Submit" name="subbtn" id="cbtn"/>
				
			</form>
		</div>
		<?php
			if(isset($_REQUEST['subbtn'])){
				include("config.php");
				$otp=$_REQUEST['otp'];
				
				$new_password=$_REQUEST['new_password'];
				$query="select otp from alluser where otp='$otp'";
				$runquery=mysqli_query($connect,$query);
				$cheak=mysqli_num_rows($runquery);
				if($cheak>0){
					$upmail=$_SESSION['mail'];
					$q="update alluser set password='$new_password',conpassword='$new_password' where otp='$otp'";
					$rq=mysqli_query($connect,$q);
					if($rq){
						header("location:login.php?reset");
					}
					else{
						echo "Password is not reset";
					}
				}
				else{
					echo "<center>Otp is incorrect</center>";
				}
			}
		?>
	<center><p style="background:gray;padding:15px;margin-top:8px;color:white">Copy right 2022 Powerb by Mamuncs</p></center>
	</div>
</body>
</html>