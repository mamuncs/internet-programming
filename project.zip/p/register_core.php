<?php
	session_start();
	include("config.php");
	
	$fname=$_REQUEST['fname'];
	$lname=$_REQUEST['lname'];
	$email=$_REQUEST['email'];
	$password=$_REQUEST['password'];
	$conpassword=$_REQUEST['conpassword'];
	$orgname=$_REQUEST['orgname'];
	$sid=$_REQUEST['sid'];
	
	$cheak_query="select email from alluser where email='$email' and orgname='$orgname'";
	$result=mysqli_query($connect,$cheak_query);
	$row=mysqli_num_rows($result);
	
	echo $row;
	//this is account cheak
  	 		if($row<1){
 						if(empty($fname&&$lname&&$email&&$password&&$conpassword&&$orgname&&$sid)){
							header("location:register.php?empty");
						}
					else if($password!=$conpassword){
							header("location:register.php?pdontmatch");
						} 
					else{
						$query="insert into alluser(fname,lname,email,orgname,password,conpassword,sid)values('$fname','$lname','$email','$orgname','$password','$conpassword','$sid')";
						$runquery=mysqli_query($connect,$query);
						if($runquery==true){
							header("location:index.php?regdone");
							$_SESSION['org']=$orgname;
							$_SESSION['fname']=$fname;
							$_SESSION['lname']=$lname;
						}
					}	
				
				
			}
			else{
				header("location:login.php?exit");
			}  
 	 
	



?>