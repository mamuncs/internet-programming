			
			<div class="fix footer">
			
								<?php
									include("config.php");
									$query="select * from content where id=8";
									$runquery=mysqli_query($connect,$query);
									while($mydata=mysqli_fetch_array($runquery)){
										?>
										<center><p><?php echo $mydata["footer"]?></p></center>
									<?php
								}
							?>
			 
				<a id="backbtn" href=""><img src="icon/back-to-top-icon-png-7.jpg" alt="back_to_top" class="animation" id="backbtn"/></a>
			</div>

	</div>
			<script type="text/javascript">
				var back_top_button = document.getElementById("backbtn");

				window.onscroll = function() {scrollfunc()};

				function scrollfunc() {
				  if (document.body.scrollTop > 10 || document.documentElement.scrollTop >10) {
						back_top_button.style.display = "block";																		
					}																																				
				  else {
					back_top_button.style.display = "none";
				  }
				}

				function Scrollback_topfunc() {
				  document.body.scrollTop = 0;
				  document.documentElement.scrollTop = 0;
				}
				
	
			</script>
							 
</body>
</html>