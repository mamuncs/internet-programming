<?php
session_start();
$org=$_SESSION['superadmin_session_org'];
if(isset($org)){
	include("config.php");

	echo $id=$_REQUEST["del_id"];
	$del_query="delete from alluser where id='$id'";
	$runquery=mysqli_query($connect,$del_query);
	if($runquery==true){
		header("location:superadmin_dasboard.php");
	}

}
else{
	header("location:index.php");
}







?>