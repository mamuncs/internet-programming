		<?php
			session_start();
			include("header.php");
		?>
			<!-- slaidbar -->
			
			<!-- maincontent -->
	
		<div class="fix maincontent">
				<div class="regfrom">
						<form action="login_core.php" method="POST">

								<label for="email">Email</label><br />
								<input type="text" name="email"/>
								<br />
								<label for="password">Password</label><br />
								<input type="text" name="password"/>
								<br />
								<label for="orgname">Organization Name</label>
								<br />
								<select name="orgname" id="orgname">
								  <option value="">Select your Association Name</option>
								  <option value="sundarban">Sundarban</option>
								  <option value="padma">Padma</option>
								  <option value="bornali">Bornali</option>
								  <option value="kopotakhho">kopotakhho</option>
								  <option value="gangchil">Gangchil</option>
								</select>
								<br />
								<input type="submit" value="Login" name="submitbtn" id="subbtn"/>
								<p><a href="sendmail.php">Forgot Password</a></p>
						</form>
						<?php
							if(isset($_REQUEST['faild'])){
								echo "<center><p style='color:red'>Please input your correct information!!</p></center>";
							}
							else if(isset($_REQUEST['exit'])){
								echo "<center><p style='color:red'>Your Account is Already exit please Login in here</p></center>";
							}
							else if(isset($_REQUEST['reset'])){
								echo "<center><p style='color:green'>Your password is Reset</p></center>";
							}
							else if(isset($_REQUEST['logout'])){
								echo "<center><p style='color:red'>You are Logout</p></center>";
							}
						?>
					
				</div>
		</div>

		<?php
			include("footer.php");
		?>
			