		<?php
			session_start();
			include("header.php");
			include("config.php");
		?>
			<!-- slaidbar -->
			
			<!-- maincontent -->
	
		<div class="fix maincontent">
				<div class="regfrom">
						<form action="" method="POST">

								<label for="email">Email</label><br />
								<input type="text" name="email"/>
								<br />
								<label for="password">Password</label><br />
								<input type="text" name="password"/>

								<br />
								<input type="submit" value="Super admin Login" name="submitbtn" id="subbtn"/>
								
						</form>
						<?php
					
						?>
						<?php
							if(isset($_REQUEST['submitbtn'])){
								$email=$_REQUEST['email'];
								$password=$_REQUEST['password'];
								if(empty($email) || empty($password)){
									echo "<center>Your email or password is empty!!</center>";
								}
								else{
									
									$query="select * from superadmin where email='$email' and password='$password'";
									$runquery=mysqli_query($connect,$query);
									$cheak=mysqli_num_rows($runquery);
									if($cheak>0){
										$_SESSION['splogin']=$email;
										header("location:superadmin_dasboard.php");
									}
									else{
										echo "<center>your Login is faild!!!!!!</center>";
									}									
								}


							}
							
						?>
					
				</div>
		</div>

		<?php
			include("footer.php");
		?>
			