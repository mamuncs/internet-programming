		<?php
			session_start();
			include("header.php");
		?>
			<!-- slaidbar -->
			
			<!-- maincontent -->
	
		<div class="fix maincontent">
				<div class="regfrom">
						<form action="" method="POST">

								<label for="email">Email</label><br />
								<input type="text" name="email"/>
								<br />
								<label for="password">Password</label><br />
								<input type="text" name="password"/>
								<br />
								<label for="orgname">Organization Name</label>
								<br />
								<select name="orgname" id="orgname">
								  <option value="#">Select your Association Name</option>
								  <option value="sundarban">Sundarban</option>
								  <option value="padma">Padma</option>
								  <option value="bornali">Bornali</option>
								  <option value="kopotakhho">kopotakhho</option>
								  <option value="gangchil">Gangchil</option>
								</select>
								<br />
								<input type="submit" value="Association admin Login" name="submitbtn" id="subbtn"/>
								<p><a href="sendmail.php">Forgot Password</a></p>
								<?php
									if(isset($_REQUEST['emailempty'])){
										echo "email is empty!!";
									}
									else if(isset($_REQUEST['passwordempty'])){
										echo "password is empty!!";
									}
									else if(isset($_REQUEST['orgnameempty'])){
										echo "Association is empty!!";
									}
								?>
						</form>
						<?php
							include("config.php");
							if(isset($_REQUEST['submitbtn'])){
								
								$email=$_REQUEST['email'];
								$password=$_REQUEST['password'];	
								$orgname=$_REQUEST['orgname'];
								if(empty($email)){
									header("location:association_admin_login.php?emailempty");
								}
								else if(empty($password)){
									header("location:association_admin_login.php?passwordempty");
								}
								else if(empty($orgname)){
									header("location:association_admin_login.php?orgnameempty");
								}
								$query="select email,password,orgname,status from alluser where email='$email' and password='$password' and orgname='$orgname' and status='admin'";
								$runquery=mysqli_query($connect,$query);
								$cheak=mysqli_num_rows($runquery);
								if($cheak>0){
									$_SESSION['orgadmin_session']=$orgname;
									header("location:orgadmin_dasboard.php");
								}
								else{
									echo "Your information is wrong!!!";
								}
								

								
							}
							
						

						?>
					
				</div>
		</div>

		<?php
			include("footer.php");
		?>
			