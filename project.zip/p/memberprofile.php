<?php
	session_start();
	
	
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>your profile</title>
	<link rel="stylesheet" href="profile.css" />
	<style>
		body {
		background-image: url('images/2.jpg');
		background-repeat:no-repeat;
		background-attachment: fixed;
	
		}
	</style>
</head>
<body>
	<div class="container">
	<center>
		<div class="pheader">

				
				<div class="imges">
					<img src="icon/fb.png" alt="" id="fb"/>
					<img src="icon/youtube.png" alt="" id="youtube"/>
					<img src="icon/in.png" alt="" id="in"/>
					<img src="img/avatar.jpg" alt="avatar" />	
					 <input type="text" placeholder="Search" id="searchbtn" name="searchitm">
				</div>
				<div class="btn">
							
					<a href="index.php">Back to Home</a>			
				</div>


		</div>
	</center>
		<div class="pcontent">
		<?php

			include('config.php');
			$sid=$_REQUEST['id'];
 			$mail=$_SESSION['mail']; 
				$org=$_SESSION['org']; 
			$query="select * from alluser where id='$sid'";
			$runquery=mysqli_query($connect,$query);
			while($mydata=mysqli_fetch_array($runquery)){
				?>
					<h3>First name: <?php echo $mydata['fname']?></h3>
					<h3>Last name: <?php echo $mydata['lname']?></h3>
					<h3>Student id: <?php echo $mydata['sid']?></h3>
					<h3>Batch no:  <?php echo $mydata['batch']?></</h3>
					<h3>Department:  <?php echo $mydata['dept']?></</h3>
					<h3>Phone number:  <?php echo $mydata['phonenumber']?></</h3>
					<h3>Whatsapp:  <?php echo $mydata['whatsapp']?></</h3>
					<h3>Blood Group:  <?php echo $mydata['bloodgroup']?></</h3>
					<h3>Wroks at:  <?php echo $mydata['wroksat']?></</h3>
					<h3>Present Address:  <?php echo $mydata['presentaddr']?></</h3>
					<h3>Parmanent Address:  <?php echo $mydata['parmanentaddr']?></</h3>
					<h3>Social link :  <?php echo $mydata['sociallink']?></</h3>
					<h3>Bio data:  <?php echo $mydata['biodata']?></</h3>
			<?php
			}
			?>
		</div>
	
	</div>
</body>
</html>