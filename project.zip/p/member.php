				<?php
					session_start();
					if(isset($_SESSION['org'])){
				?>
						<!-- header area -->
<!DOCTYPE html>
<html lang="es-us">
<meta charset="utf-8">
<head>
<title> Student Association management in DUET </title>
<link href="style.css" rel="stylesheet" type="text/css">
<link href="content.css" rel="stylesheet" type="text/css">

</head>
<body>	
	<div class="fix wraper">
			<div class="fix mainheader">
					<div class="fix new_header">
						<div class="fix title">
							<a href="https://www.facebook.com/"><img src="icon/fb.png" alt="" style="width:30px;height:30px;float:left;border-radius:50%;margin-right:10px;"/></a>
							<a href="htpps://www.youtube.com/"><img src="icon/youtube.png" alt="" style="width:30px;height:30px;float:left;border-radius:50%;"/></a>
				
								<?php
									include("config.php");
									$query="select * from content where id=8";
									$runquery=mysqli_query($connect,$query);
									while($mydata=mysqli_fetch_array($runquery)){
										?>
										<center><h2><?php echo $mydata["header"]?></h2></center>
									<?php
								}
							?>
							<input type="text" placeholder="search" name="searchbtn" style="float:right;padding:4px;margin-top:-25px;border-radius:4px;"/>
						</div>

					</div>  
					<div class="fix manu">
						<ul>
							<li><a href="index.php">HOME</a></li>
							<li><a href="?contact">CONTACT</a></li>
							<li><a href ="profile.php">PROFILE</a></li>
							<li><a href="member.php">MEMBERS</a></li>
							
							
							<li><a href="#">ADMIN</a>
									<ul>
										<li><a href="superadmin_login.php">Super admin</a></li>
										<li><a href="association_admin_login.php">Association admin</a></li>
										<li><a href="admin_logout.php">Logout</a></li>
										
									</ul>
							</li>
							<li><a href ="#">USER</a>
									<ul>
										
										
													<?php
											if(isset($_SESSION['mail'])){
												echo "<li><a href='logout.php'>Logout</a></li>";	
												echo "<li><a href='profile.php'>Profile</a></li>";	
											}
											else{
												echo "<li><a href='register.php'>Register</a></li>";
												echo "<li><a href='login.php'>Login</a></li>";
											}
										?>
										
									</ul>
							
							</li>
						</ul>
					</div>
			</div>
			
		
				<div class="fix maincontent" style="padding:10px;">
							<?php
					if(isset($_SESSION['org'])){
							
								
								
								

							?>
						<center>
							<table>
								<tr>
									<th>First name&nbsp;&nbsp;&nbsp;&nbsp;</th>
									<th>Last name&nbsp;&nbsp;&nbsp;&nbsp;</th>
									<th>Student Id&nbsp;&nbsp;&nbsp;&nbsp;</th>
									<th>Association Name&nbsp;&nbsp;&nbsp;&nbsp;</u></th>
									<th>Profile&nbsp;&nbsp;&nbsp;&nbsp;</th>
								</tr>
								
									
									<?php
									$orgname=$_SESSION['org'];
									$query="select * from alluser where orgname='$orgname'";
									include("config.php");
									$runquery=mysqli_query($connect,$query);
									while($mydata=mysqli_fetch_array($runquery)){
										
										?>
										<tr>
										
											<td><?php echo $mydata['fname']?></td>
											<td><?php echo $mydata['lname']?></td>
											<td><?php echo $mydata['sid']?></td>
											<td><?php echo $mydata['orgname']?></td>
											<td><a href="memberprofile.php?id=<?php echo $mydata['id']?>">view</a></td>
										</tr>
										<?php
										
										}
										
									?>

									
							
									
							</table>
						</center>
					<?php
					}
					else{
						echo "<p><font style='color:red'>Member Area is Restricted Please login !!</font></p>";
						
					}
					?>
				</div>
		
				<!-- saidbar -->
				<?php
					include('footer.php');
				?>
				<?php
					}
					else{
						header("location:login.php");
					}
					?>
				