				<?php
					session_start();
					$splogin=$_SESSION['splogin'];
					if(isset($splogin)){
						
					
				?>
						<!-- header area -->
<!DOCTYPE html>
<html lang="es-us">
<meta charset="utf-8">
<head>
<title> Student Association management in DUET </title>
<link href="style.css" rel="stylesheet" type="text/css">
<link href="content.css" rel="stylesheet" type="text/css">

</head>
<body>	
	<div class="fix wraper">
			<div class="fix mainheader">
					<div class="fix new_header">
						<div class="fix title">
							<a href="https://www.facebook.com/"><img src="icon/fb.png" alt="" style="width:30px;height:30px;float:left;border-radius:50%;margin-right:10px;"/></a>
							<a href="htpps://www.youtube.com/"><img src="icon/youtube.png" alt="" style="width:30px;height:30px;float:left;border-radius:50%;"/></a>
				
								<?php
									include("config.php");
									$query="select * from content where id=8";
									$runquery=mysqli_query($connect,$query);
									while($mydata=mysqli_fetch_array($runquery)){
										?>
										<center><h2><?php echo $mydata["header"]?></h2></center>
									<?php
								}
							?>
							<input type="text" placeholder="search" name="searchbtn" style="float:right;padding:4px;margin-top:-25px;border-radius:4px;"/>
						</div>

					</div>  
					<div class="fix manu">
						<ul>
							<li><a href="index.php">HOME</a></li>
							<li><a href="#">CONTACT</a></li>
							<li><a href ="#">INFO</a></li>
							<li><a href="superadmin_dasboard.php">DASBOARD</a></li>
							
							
							<li><a href="#">ADMIN</a>
									<ul>

										
										<li><a href='superadmin_login.php'>Super admin</a></li>
					
										<li><a href="login.php">Admin Login</a></li>
										<li><a href="admin_logout.php">Logout</a></li>
										
									</ul>
							</li>
							<li><a href ="#">USER</a>
									<ul>
										
										
													<?php
											if(isset($_SESSION['mail'])){
												echo "<li><a href='logout.php'>Logout</a></li>";	
												echo "<li><a href='profile.php'>Profile</a></li>";	
											}
											else{
												echo "<li><a href='register.php'>Register</a></li>";
												echo "<li><a href='login.php'>Login</a></li>";
											}
										?>
									</ul>
							
							</li>
						</ul>
					</div>
			</div>
			
		
				<div class="fix maincontent" style="padding:5px;">
					<div class="leftbar">

						<h4>Name of Association </h4>
						<h5>Sundarban</h5>
						<h5>Padma</h5>
						<h5>Bornali</h5>
						<h5>Kopotakhho</h5>
						<h5>Gangchil</h5>
						<hr />
						<h4>Create new header and footer</h4>
						<form action="" method="POST">
							<input type="text" name="header" placeholder="header" style="width:90%;"/>
				
							<input type="text" name="footer" placeholder="footer" style="width:90%;"/>
							<input type="submit" value="submit" name="header_footer" style="width:50%;margin-top:3px;background:green;color:white"/>
						</form>
						<i><p>Update both header and footer</p></i>
					
						<?php
							if(isset($_REQUEST["header_footer"])){
								include("config.php");
								$header=$_REQUEST['header'];
								$footer=$_REQUEST['footer'];
								if(empty($header&&$footer)){
									echo "Input header footer";
								}
								else{
									$query="UPDATE content SET header='$header',footer='$footer' WHERE id='8'";
									$runquery=mysqli_query($connect,$query);
									if($runquery==true){
										header("location:superadmin_dasboard.php");
									}
								}
							}
						?>

						
					</div>


					
							<div class="allcontent">
								<h2>Add student</h2>
								
								<form action="" method="POST">

										<label for="First Name">First Name</label><br />
										<input type="text" name="fname"/>
										<br />
										<label for="Last Name">Last Name</label><br />
										<input type="text" name="lname"/>
										<br />
										<label for="Email">Email</label><br />
										<input type="email" name="email"/>
										<br />
										<label for="Student Id">Student Id</label><br />
										<input type="text" name="sid"/>
										<br />
										<label for="Status">Status</label><br />
										<select name="status" id="orgname">
										  <option value="">Select your User role</option>
										  <option value="admin">Admin</option>
										  <option value="user">User</option>

										</select>
										<br />
										<label for="password">Password</label><br />
										<input type="text" name="password"/>
										<br />
										<label for="orgname">Organization Name</label>
										<br />
										<select name="orgname" id="orgname">
										  <option value="">Select your Association Name</option>
										  <option value="sundarban">Sundarban</option>
										  <option value="padma">Padma</option>
										  <option value="bornali">Bornali</option>
										  <option value="kopotakhho">kopotakhho</option>
										  <option value="gangchil">Gangchil</option>
										</select>
										<br />
										<input type="submit" value="Add_User" name="submitbtn" id="subbtn"/>
										
								</form>
								
							</div>
	
							<div class="allcontent">
								<h2>Add Super admin</h2>
								
								<form action="" method="POST">

										<label for="Email">Email</label><br />
										<input type="text" name="email"/>
										<br />

										<br />
										<label for="password">Password</label><br />
										<input type="text" name="password"/>
										<br />
										<label for="Confirm password">Confirm password</label><br />
										<input type="text" name="conpassword"/>
										<br />
										<input type="submit" value="Add_super admin" name="admin" id="subbtn"/>
										
								</form>
								
							</div>
							<div class="homupdate">
							<h2>Update home</h2>
								<form action="" method="POST">	
										<textarea name="homecontent" id="" cols="25" rows="7" required >	
										</textarea>
										<br />
										<input type="submit" value="Update" name="homepage" id="subbtn"/>							
								</form>
							</div>

							
								<div class="rightsideber">
								<h2>Show student</h2>
								<form action="" method="POST">

										<select name="orgname" id="orgname">
										<option value="">Select your Association Name</option>
										  <option value="sundarban">Sundarban</option>
										  <option value="padma">Padma</option>
										  <option value="bornali">Bornali</option>
										  <option value="kopotakhho">Kopotakhho</option>
										  <option value="gangchil">Gangchil</option>
										</select>
									<br />
									<input type="submit" value="Show" id="subbtn"/>
								</form>
								</div>				
					

				</div>
					<div class="data" style="padding:10px;text-align:center">
						<?php
							include("config.php");
							if(!empty($_REQUEST['orgname'])){
								?>
								<table border="1px solid green" style="width:100%;margin:0 auto">
									<tr>
										<td>First Name</td>
										<td>Last Name</td>
										<td>Student Id</td>
										<td>Association Name</td>
										<td>Profile</td>
										<td>Edit profile</td>
										<td>delete profile</td>
										<td>Status</td>
										
									</tr>
								<?php
								$orgname=$_REQUEST['orgname'];
								$_SESSION['superadmin_session_org']=$orgname;
								$query="select * from alluser where orgname='$orgname'";
								$runquery=mysqli_query($connect,$query);
								while($mydata=mysqli_fetch_array($runquery)){
									?>
								
									<tr>
										<td><?php echo $mydata['fname'];?></td>
										<td><?php echo $mydata['lname'];?></td>
										<td><?php echo $mydata['sid'];?></td>
										<td><?php echo $mydata['orgname'];?></td>
										<td><a href="superadmin_profile_view.php?view_id=<?php echo $mydata['id']?>">view</a></td>
										<td><a href="superadmin_edit.php?id=<?php echo $mydata['id']?>">Edit</a></td>
										<td><a onclick="return confirm('Are you want to delete your Account?');" href="superadmin_delete_core.php?del_id=<?php echo $mydata['id']?>">Delete</a></td>
										<td><?php echo $mydata['status']?></td>
									</tr>
								<?php
								}
								?>
								</table>
								
								<?php
								
								
							}
							
								
						?>
						
					
				
					</div>
				<!-- saidbar -->
					<?php
					//all dasboard panel an validation php code
						//admin add
						if(isset($_REQUEST['admin'])){
							include("config.php");
							$email=$_REQUEST['email'];
							$password=$_REQUEST['password'];
							$conpassword=$_REQUEST['conpassword'];
							if(empty($email&&$password&&$conpassword)){
								echo "<center><font color='red'>your fields are empty</font></center>";
							}
							else if($password==$conpassword){
								$query="insert into superadmin(email,password) values('$email','$password')";
								$runquery=mysqli_query($connect,$query); 
								echo "<center><font color='green'>Admin is Added</font></center>";
							}
							else{
								echo "<center><font color='red'>Your password does not match!!</font></center>";
							}
							
							
						}
							//student add
						if(isset($_REQUEST["submitbtn"])){
								$fname=$_REQUEST['fname'];
								$lname=$_REQUEST['lname'];
								$email=$_REQUEST['email'];
								$sid=$_REQUEST['sid'];
								$status=$_REQUEST['status'];
								$orgname=$_REQUEST['orgname'];
								$password=$_REQUEST['password'];
								if(empty($fname&&$lname&&$email&&$sid&&$status&&$orgname&&$password)){
									echo "<center><font color='red'>Fields are empty</font></center>";	
								}
								else{
									$query="insert into alluser(fname,lname,email,orgname,password,conpassword,status,sid)values('$fname','$lname','$email','$orgname','$password','$password','$status','$sid')";
									$runquery=mysqli_query($connect,$query);
									if($runquery==true){
										//echo "<center>Fields are empty</center>";
									}

										
								}
						}
						if(isset($_REQUEST['homepage'])){
							include("config.php");
							$homecontent=$_REQUEST['homecontent'];
							if(empty($homecontent)){
								header("location:superadmin_dasboard.php");
							}
							else{
								
								$query="update content set home='$homecontent' where id=8";
								$runquery=mysqli_query($connect,$query);
								
								
							}
						}
				
					
					?>
				<?php
					include('footer.php');
				?>
				<?php
					}
					else{
						header("location:index.php");
					}
					?>