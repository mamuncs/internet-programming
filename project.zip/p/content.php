				

				<?php
					include("config.php");
					$query="SELECT home FROM content";
					$runquery=mysqli_query($connect,$query);
					while($mydata=mysqli_fetch_array($runquery)){
						echo $mydata['home'];
					}
				?>
			 