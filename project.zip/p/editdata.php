				<?php
					session_start();
				?>
						<!-- header area -->
<!DOCTYPE html>
<html lang="es-us">
<meta charset="utf-8">
<head>
<title> Student Association management in DUET </title>
<link href="style.css" rel="stylesheet" type="text/css">
<link href="content.css" rel="stylesheet" type="text/css">

</head>
<body>	
	<div class="fix wraper">
			<div class="fix mainheader">
					<div class="fix new_header">
						<div class="fix title">
							<img src="icon/fb.png" alt="" style="width:30px;height:30px;float:left;border-radius:50%;margin-right:10px;"/>
							<img src="icon/youtube.png" alt="" style="width:30px;height:30px;float:left;border-radius:50%;"/>
				
							<center><h2>Student Welfare Association in DUET</h2></center>
							<input type="text" placeholder="search" name="searchbtn" style="float:right;padding:4px;margin-top:-25px;border-radius:4px;"/>
						</div>

					</div>  
					<div class="fix manu">
						<ul>
							<li><a href="index.php">HOME</a></li>
							<li><a href="#">CONTACT</a></li>
							<li><a href ="#">INFO</a></li>
							<li><a href="member.php">MEMBERS</a></li>
							
							
							<li><a href="#">ADMIN</a>
									<ul>
										<li><a href="login.php">Login</a></li>
										
									</ul>
							</li>
							<li><a href ="#">USER</a>
									<ul>
										
										
													<?php
											if(isset($_SESSION['mail'])){
												echo "<li><a href='profile.php'>Profile</a></li>";	
												echo "<li><a href='logout.php'>Logout</a></li>";	
												
											}
											else{
												echo "<li><a href='register.php'>Register</a></li>";
												echo "<li><a href='login.php'>Login</a></li>";
											}
										?>
									</ul>
							
							</li>
						</ul>
					</div>
			</div>
			
		
				<div class="fix maincontent" style="padding:10px;">
						<div class="regfrom">
							<?php
								include("config.php");
								$editmail=$_SESSION['mail'];
								/*this is session org befor change*/
								/* $editorg=$_SESSION['org']; */
								$query="select * from alluser where email='$editmail'";
								$runquery=mysqli_query($connect,$query);
								while($mydata=mysqli_fetch_array($runquery)){
								?>	
								<center>
									<form action="editdata_core.php" method="POST">
										<label for="">Frist Name</label><br />
										<input type="text" name="fname" value="<?php echo $mydata['fname'];?>"/><br />
										<label for="">Last Name</label><br />
										<input type="text" name="lname" value="<?php echo $mydata['lname'];?>"/><br />
										<label for="">Student Id</label><br />
										<input type="text" name="sid" value="<?php echo $mydata['sid'];?>"/><br />
										<label for="">Batch no</label><br />
										<input type="text" name="batch" value="<?php echo $mydata['batch'];?>"/><br />
										<label for="">Department</label><br />
										<input type="text" name="dept" value="<?php echo $mydata['dept'];?>"/><br />
										<label for="">Phone number</label><br />
										<input type="text" name="phonenumber" value="<?php echo $mydata['phonenumber'];?>"/><br />
										<label for="">Whatsapp number</label><br />
										<input type="text" name="whatsapp" value="<?php echo $mydata['whatsapp'];?>"/><br />
										<label for="">Blood Group</label><br />
										<input type="text" name="bloodgroup" value="<?php echo $mydata['bloodgroup'];?>"/><br />
										<label for="">Wroks at</label><br />
										<input type="text" name="wroksat" value="<?php echo $mydata['wroksat'];?>"/><br />
										<label for="">Present Address</label><br />
										<input type="text" name="presentaddr" value="<?php echo $mydata['presentaddr'];?>"/><br />
										<label for="">Parmanent Address</label><br />
										<input type="text" name="parmanentaddr" value="<?php echo $mydata['parmanentaddr'];?>"/><br />
										<label for="">Social Link</label><br />
										<input type="text" name="sociallink" value="<?php echo $mydata['sociallink'];?>"/><br />
										<label for="">Biodata</label><br />
										<input type="text" name="biodata" value="<?php echo $mydata['biodata'];?>"/><br />
										<input type="submit" value="Update Profile" id="subbtn"/>
										
										<input type="hidden" name="editprofile" value="<?php echo $mydata['id'];?>"/>
									
									</form>
								</center>	
							<?php
								}
							?>		

						</div>
				</div>
		
				<!-- saidbar -->
				<?php
					include('footer.php');
				?>
				