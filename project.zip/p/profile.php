<?php
	session_start();
	if(isset($_SESSION['mail'])){
		
	
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>your profile</title>
	<link rel="stylesheet" href="profile.css" />
	<style>
		body {
		background-image: url('images/2.jpg');
		background-repeat:no-repeat;
		background-attachment: fixed;
		}
	</style>
</head>
<body>
	<div class="container">
	<center>
		<div class="pheader">

				
				<div class="imges">
				<?php
						include('config.php');
						$mail=$_SESSION['mail'];
						$org=$_SESSION['org'];
							$query="select avatar from alluser where email='$mail'";
							$runquery=mysqli_query($connect,$query);
							while($mydata=mysqli_fetch_array($runquery)) {
								
				?>
				
					<a href="https://www.facebook.com"><img src="icon/fb.png" alt="" id="fb"/></a>
					<a href="https://www.youtube.com/"><img src="icon/youtube.png" alt="" id="youtube"/></a>
					<a href="https://www.linkedin.com/"><img src="icon/in.png" alt="" id="in"/></a>
					<center><a href="profile.php"><img src="img/<?php echo $mydata['avatar']?>" alt="Profile picture" /></a></center>
						<form action="">
							<input type="text" placeholder="Search" id="searchbtn" name="searchitm">
							
						</form>
					
				<?php	
				}
				?>
				</div>
				<div class="btn">
					<a href="editdata.php">Update Profile</a>
					<a onclick="return confirm('Are you want to delete your Account?');" href="deletedata_core.php">Delete Account</a>			
					<a href="avatar.php">Upload Photo</a>			
					<a href="index.php">Back to Home</a>			
				</div>


		</div>
	</center>
	
		<div class="pcontent">
		<?php
			include('config.php');
				$mail=$_SESSION['mail'];
				$org=$_SESSION['org'];
			$query="select * from alluser where email='$mail'";
			$runquery=mysqli_query($connect,$query);
			while($mydata=mysqli_fetch_array($runquery)){
				?>
					
					<h3>First name: <?php echo $mydata['fname']?></h3>
					<h3>Last name: <?php echo $mydata['lname']?></h3>
					<h3>Student id: <?php echo $mydata['sid']?></h3>
					<h3>Batch no: <?php echo $mydata['batch']?></h3>
					<h3>Department: <?php echo $mydata['dept']?></h3>
					<h3>Phone number: <?php echo $mydata['phonenumber']?></h3>
					<h3>Association Name: <?php echo $mydata['orgname']?></h3>
					<h3>Whatsapp: <?php echo $mydata['whatsapp']?></h3>
					<h3>Blood Group: <?php echo $mydata['bloodgroup']?></h3>
					<h3>Wroks at: <?php echo $mydata['wroksat']?></h3>
					<h3>Present Address: <?php echo $mydata['presentaddr']?></h3>
					<h3>Parmanent Address: <?php echo $mydata['parmanentaddr']?></h3>
					<h3>Social link : <?php echo $mydata['sociallink']?></a></h3>
					<h3>Bio data: <?php echo $mydata['biodata']?></h3>
					
			<?php
			}
			//echo $_SESSION['org'];
			?>
		</div>
		
	
	</div>
</body>
</html>
<?php
	}
	else{
		header("location:index.php");
	}
?>