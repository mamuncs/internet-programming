				<?php
					session_start();
				?>
						<!-- header area -->
<!DOCTYPE html>
<html lang="es-us">
<meta charset="utf-8">
<head>
<title> Student Association management in DUET </title>
<link href="style.css" rel="stylesheet" type="text/css">
<link href="content.css" rel="stylesheet" type="text/css">

</head>
<body>	
	<div class="fix wraper">
			<div class="fix mainheader">
					<div class="fix new_header">
						<div class="fix title">
							<img src="icon/fb.png" alt="" style="width:30px;height:30px;float:left;border-radius:50%;margin-right:10px;"/>
							<img src="icon/youtube.png" alt="" style="width:30px;height:30px;float:left;border-radius:50%;"/>
				
							<center><h2>Student Welfare Association in DUET</h2></center>
							<input type="text" placeholder="search" name="searchbtn" style="float:right;padding:4px;margin-top:-25px;border-radius:4px;"/>
						</div>

					</div>  
					<div class="fix manu">
						<ul>
							<li><a href="index.php">HOME</a></li>
							<li><a href="#">CONTACT</a></li>
							<li><a href ="superadmin.php">SUPER ADMIN</a></li>
							<li><a href="member.php">MEMBERS</a></li>
							
							
							<li><a href="#">ADMIN</a>
									<ul>
										
										<li><a href="">Super admin</a></li>
										<li><a href="login.php">Login</a></li>
										
									</ul>
							</li>
							<li><a href ="#">USER</a>
									<ul>
										
										
													<?php
											if(isset($_SESSION['mail'])){
												echo "<li><a href='logout.php'>Logout</a></li>";	
												echo "<li><a href='profile.php'>Profile</a></li>";	
											}
											else{
												echo "<li><a href='register.php'>Register</a></li>";
												echo "<li><a href='login.php'>Login</a></li>";
											}
										?>
									</ul>
							
							</li>
						</ul>
					</div>
			</div>
			
		
				<div class="fix maincontent" style="padding:10px;">
					<?php
						include("config.php");
						echo $id=$_REQUEST['view_id'];
						echo $org=$_SESSION['superadmin_session_org'];
					/* 	$query="select * from $org where id=$id";
						$runquery=mysqli_query($connect,$query);
						while($mydata=mysqli_fetch_array($runquery)){
							echo $mydata['fname'];
						} */
					?>
						<h2>Student information</h2>
						<p>Frist name: </p>
						<p>Last name: </p>
						<p>Student id: </p>
						<p>Batch:</p>
						<p>Orgname:</p>
					
				</div>
		
				<!-- saidbar -->
				<?php
					include('footer.php');
				?>
				