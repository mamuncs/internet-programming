<?php
session_start();
include("config.php");
$fname=$_REQUEST["fname"];
$lname=$_REQUEST["lname"];
$sid=$_REQUEST["sid"];
$batch=$_REQUEST["batch"];
$dept=$_REQUEST["dept"];
$phonenumber=$_REQUEST["phonenumber"];
$whatsapp=$_REQUEST["whatsapp"];
$bloodgroup=$_REQUEST["bloodgroup"];
$wroksat=$_REQUEST["wroksat"];
$presentaddr=$_REQUEST["presentaddr"];
$parmanentaddr=$_REQUEST["parmanentaddr"];
$sociallink=$_REQUEST["sociallink"];
$biodata=$_REQUEST["biodata"];

$editprofile=$_REQUEST["editprofile"];



$update_table=$_SESSION['org'];
$query="update alluser set fname='$fname',lname='$lname',sid='$sid',batch='$batch',dept='$dept',phonenumber='$phonenumber',whatsapp='$whatsapp',bloodgroup='$bloodgroup',wroksat='$wroksat',presentaddr='$presentaddr',parmanentaddr='$parmanentaddr',sociallink='$sociallink',biodata='$biodata' where id='$editprofile'";
$runquery=mysqli_query($connect,$query);
if($runquery==true){
	header("location:profile.php");
}










?>