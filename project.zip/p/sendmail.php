<?php
	session_start();
	
	
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>your profile</title>
	<link rel="stylesheet" href="style.css" type="text/css"/>
	
</head>
<body>
	<div class="sendmail">
			<center><h3>Student Association Welfare in DUET</h3></center>
			<hr />
		<div class="mail">
			<form action="" method="POST">
				<input type="email" name="email" placeholder="Enter your email"/>
				<input type="submit" value="Send-OTP" name="sendemail" id="cbtn"/>
			</form>
		</div>
		
			<?php
				if(isset($_REQUEST['sendemail'])){
					$mail=$_REQUEST['email'];
					$otp=rand();
					$sub="Student Association welfare in DUET";
					$body=$otp;
					$headers="From:mamun46471@gmail.com";
					if(mail($mail,$sub,$body,$headers)){
							echo "<center>Massage sent to successfull</center>";
							
							include("config.php");
							$query="update alluser set otp='$body' where email='$mail'";
							$runquery=mysqli_query($connect,$query);
							if($runquery){
								$_SESSION['mail']=$mail;
								header("location:password_reset_user.php");
							}
					}
				}
			
			?>
				<center><p style="background:gray;padding:15px;margin-top:8px;color:white">Copy right 2022 Powerd by Mamuncs</p></center>
	</div>
</body>
</html>