				<?php
					session_start();
				?>			<!-- header area -->
				<?php
					include("header.php");
				
				?>
				<?php
					if(isset($_REQUEST['searchbtn'])){
						$s=$_REQUEST['searchbtn'];
						echo $s;
					}
				?>
			<div class="fix maincontent">
				<?php
					
					if(isset($_REQUEST['regdone'])){
						$org=$_SESSION['org'];
						$fname=$_SESSION['fname'];
						$lname=$_SESSION['lname'];
						echo "<center><h3 style='margin-top:10px;'>Welcome <i>$fname $lname</i> for completed Registration</h3></center>";
						echo "<center><h3>For <i>$org</i> Association  <a style='text-decoration:none;' href='login.php'>click here to login</a></h3></center>";
						echo "<br />";
					}

				?>
				<?php
					include("maincontent.php");
				?> 
				
			</div>
				<!-- saidbar -->
				<?php
					include('footer.php');
				?>