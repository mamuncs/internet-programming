					
			<!-- maincontent -->
					<!-- saidbar -->
					<div class="fix saidbar"><h1 class="animation">Related Link</h1>
							<ul><font size="4">
								<li><a link href="https://www.duet.ac.bd">Dhaka University of engineering and technology</a></li>
								<li><a href="https://www.buet.ac.bd/">Bangladesh University of engineering and technology</a></li>
								<li><a href="https://www.cuet.ac.bd/">chittagong University of engineering and technology</a></li>
								<li><a href="https://www.kuet.ac.bd/">khulna University of engineering and technology</a></li>
								<li><a href="https://www.ruet.ac.bd/">Rajshahi University of engineering and technology</a></li>
								<li><a href="https://bcc.gov.bd/">Bangladesh Computer Council (BCC)</a></li>
							</ul></font>
							<hr />
							<h1 class="animation">Vision</h1>
							<p>Inspiring and motivating.</br>Realistic and applicable..</br> Easy to communicate.....<br>give peo
							ple an insight about your organization’s interests.</p>
							
							<h1 class="animation">Mission </h1>
							<p style="margin-bottom:10px;"> Consistent, clear and powerful.</br>Memorable and easy to understand.</br>Inclusiv
							e and actionable</br> guide for day-to-day operations</p>
							<hr />
							<h1 class="animation"><a href="">Event</h1></a>
							<h1 class="animation"><a href="">News</h1></a>
							<h1 class="animation"><a href="">Result</h1></a>
							<h1 class="animation"><a href="">Notice</h1></a>
					</div>
					<div class="fix content">
							<div class="fix part1">
								<?php
									if(isset($_REQUEST['sundarban'])){
										include("pages/sundarban.php");
									}
									else if(isset($_REQUEST['faridpur'])){
										include("pages/faridpur.php");
									}
									else if(isset($_REQUEST['contact'])){
										include("pages/contact.php");
									}
									else if(isset($_REQUEST['info'])){
										include("pages/info.php");
									}
									else{
										include("content.php");
									}
									
								?>
							</div>
							<div class="fix part2">
								  <bold><p>All Organization of DUET</p></bold>
								  <hr />
								  <ul style="margin-top:10px;"><FONT SIZE="3">
								  <li><a href="?sundarban">SUNDARBAN</a></li>
								  <li><a href="?meghna">MEGNA</a></li>
								  <li><a href="?bornali">BORNALI</a></li>
								  <li><a href="?gangchil">GANGCHILL</a></li>
								  <li><a href="?korotoa">KORTOYA</a></li>
								  <li><a href="?padma">PADMA</a></li>
								  <li><a href="?basani">BASANI SETUBONDON</a></li>
								  <li><a href="?chandrodip">CHANDRADIP</a></li>
								  <li><a href="?pabna">PABNA </a></li>
								  <li><a href="?faridpur">FARIDPUR </a></li>
								  
								   
								  </ul></FONT>
								<img src="img/1 copy.jpg" alt="" />
							</div>
					</div>