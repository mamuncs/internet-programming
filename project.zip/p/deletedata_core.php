<?php
session_start();
include("config.php");
$delete_email=$_SESSION['mail'];
/* /*session user */
/* $delete_table=$_SESSION['org'];  */

$query="delete from alluser where email='$delete_email'";
$runquery=mysqli_query($connect,$query);
if($runquery==true){
	session_destroy();
	header("location:index.php");
}









?>