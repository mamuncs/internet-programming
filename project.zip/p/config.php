
<?php
		$host="localhost";
		$dbuser="root";
		$dbpwd="";
		$dbname="duetorg";
		$connect=mysqli_connect($host,$dbuser,$dbpwd,$dbname);


?>