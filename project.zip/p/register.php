				<?php
					session_start();
					include("header.php");
				
				?>
			<!-- slaidbar -->
			
			<!-- maincontent -->
			
			<div class="fix maincontent">
				<div class="regfrom">
						<form action="register_core.php" method="POST">
								<label for="">Frist Name</label><br />
								<input type="text" name="fname" required />
								<br />
								<label for="">Last Name</label><br />
								<input type="text" name="lname" required  />
								<br />
								<label for="">Email</label><br />
								<input type="text" name="email" required />
								<br />
								<label for="">Student Id</label><br />
								<input type="text" name="sid" />
								<br />
								<label for="">Password</label><br />
								<input type="text" name="password" required />
								<br />
								<label for="">Confrim password</label><br />
								<input type="text" name="conpassword" required />
								<br />

								<label for="orgname">Organization Name</label>
								<br />

								<select name="orgname" id="orgname">
								<option value="">Select your Association Name</option>
								  <option value="sundarban">Sundarban</option>
								  <option value="padma">Padma</option>
								  <option value="bornali">Bornali</option>
								  <option value="kopotakhho">Kopotakhho</option>
								  <option value="gangchil">Gangchil</option>
								</select>
								<input type="submit" value="Register" name="submitbtn" id="subbtn"/>
						</form>
						<?php
							if(isset($_REQUEST['pdontmatch'])){
								echo "<center><p style='color:red'>Password do not match !!</p></center>";
							}
							else if(isset($_REQUEST['empty'])){
								echo "<center><p style='color:red'>Fill up the all fields!!</p></center>";
							}
						?>

				</div>

		</div>
			
			<?php
				include("footer.php");
			?>
