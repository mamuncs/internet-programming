<?php
session_start();
if(isset($_SESSION['orgadmin_session'])){				
?>
						<!-- header area -->
<!DOCTYPE html>
<html lang="es-us">
<meta charset="utf-8">
<head>
<title> Student Association management in DUET </title>
<link href="style.css" rel="stylesheet" type="text/css">
<link href="content.css" rel="stylesheet" type="text/css">

</head>
<body>	
	<div class="fix wraper">
			<div class="fix mainheader">
					<div class="fix new_header">
						<div class="fix title">
							<img src="icon/fb.png" alt="" style="width:30px;height:30px;float:left;border-radius:50%;margin-right:10px;"/>
							<img src="icon/youtube.png" alt="" style="width:30px;height:30px;float:left;border-radius:50%;"/>
				
							<center><h2>Student Welfare Association in DUET</h2></center>
							<input type="text" placeholder="search" name="searchbtn" style="float:right;padding:4px;margin-top:-25px;border-radius:4px;"/>
						</div>

					</div>  

			</div>
			
		
				<div class="fix maincontent" style="padding:10px;margin:0 auto;width:80%">
					<?php
						include("config.php");
						$id=$_REQUEST['view_id'];
						$org=$_SESSION['orgadmin_session'];
					 	$query="select * from alluser where id=$id";
						$runquery=mysqli_query($connect,$query);
						while($mydata=mysqli_fetch_array($runquery)){
							?>
							
							<h2>Student information</h2>
							<br />
							
							<h4>Frist name: <?php echo $mydata['fname']?></h4>
							<h4>Last name: <?php echo $mydata['lname']?></h4>
							<h4>Student id: <?php echo $mydata['sid']?></h4>
							<h4>Orgname: <?php echo $mydata['orgname']?></h4>
							<h4>Batch: <?php echo $mydata['batch']?></h4>
							<h4>Present Address: <?php echo $mydata['presentaddr']?></h4>
							<h4>Parmanent Address: <?php echo $mydata['parmanentaddr']?></h4>
							<h4>Phone number: <?php echo $mydata['phonenumber']?></h4>
							<h4>Blood Group: <?php echo $mydata['bloodgroup']?></h4>
							<h4>social Link: <?php echo $mydata['sociallink']?></h4>
							<h4>Bio Data: <?php echo $mydata['biodata']?></h4>
							
							
							<p id="back_button"><a href="orgadmin_dasboard.php">Back Dasboard</a></p>
							
					<?php
						} 
					?>

					
				</div>
		
				<!-- saidbar -->
				<?php
					include('footer.php');
				?>
				<?php
					}
					else{
						header("location:index.php");
					}
				?>