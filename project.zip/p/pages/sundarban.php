


<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>sundarban site</title>
	<link rel="stylesheet" href="content.css" />
</head>
<body>
	<h4>The SEF President</h4>
<p>Md.Jhangir Alam</p>
<p>Dept of CSE,DUET</p>

<P>The sundarban student Engineers forum SEF ,Khulna.It is one of famous Organization in
	DUET.
	


</p>
</body>
</html>
