<h3>DUET is the university of choice for
 future engineers and architects in Bangl
 adesh because of lively campus life. In 1
 983, the campus at Tejgaon, Dhaka was shif
 ted to its permanent campus in the heart of 
 Gazipur city (40 km north of Dhaka, the capit
 al city of Bangladesh), with convenient access 
 to the Hazrat Shahjalal International Airport,
 Gazipur Railway Station, and Gazipur City Bus 
 Terminals. The university’s physical expansion 
 over the years has been significant, with new a
 cademic buildings, a number of student’s res
 idential halls, a central library, a w
 ell equipped medical center, a student w
 elfare center, 
and an auditorium complex, among ot
her infrastructures. </h3>