

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>sundarban site</title>
	<link rel="stylesheet" href="content.css" />
</head>
<body>
	<h4>The president of Faridpur</h4>
	<p>Md.Jhangir Alam</p>
	<p>Dept of CSE,DUET</p>

<P>The Dhan siri Assocaiton is  student welfare in Faridpur zila polytechnic</p>
	
	


</p>
</body>
</html>
