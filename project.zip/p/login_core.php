<?php
session_start();

include("config.php");
			$email=$_REQUEST['email'];
			$password=$_REQUEST['password'];
			$orgname=$_REQUEST['orgname'];
			
			$query="select email,password,orgname from alluser where email='$email' and password='$password' and orgname='$orgname'";
			$runquery=mysqli_query($connect,$query);
			$cheak=mysqli_num_rows($runquery);
			if($cheak>0){
				$_SESSION['mail']=$email;//session email address
				$_SESSION['org']=$orgname;//session org name
				header("location:profile.php");

			}
			else{
				header("location:login.php?faild");
				
			}








?>